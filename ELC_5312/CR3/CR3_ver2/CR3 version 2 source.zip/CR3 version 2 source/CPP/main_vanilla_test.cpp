// main_vanilla_test.cpp
#include "chu_init.h"
#include "blink4_core.h"
#include "uart_core.h"

#include "chu_init.h"
#include "blink4_core.h"
#include "uart_core.h"

extern UartCore uart;

// --- tiny print helpers
static inline void nl() { uart.disp("\r\n"); }
static inline void sp() { uart.disp(" "); }

// Convert HALF-PERIOD tick count -> milliseconds (integer, rounded)
// ticks = ms * (CLK_HZ/1000)/2  =>  ms = ticks * 2000 / CLK_HZ
static inline uint32_t ticks_to_ms(uint32_t ticks) {
  if (ticks == 0) return 0;
  return (uint32_t)(((uint64_t)ticks * 2000u + (CLK_HZ/2)) / CLK_HZ); // rounded
}

// Print frequency as X.YYY Hz using integer math (no floats)
static void print_hz_from_full_ms(uint32_t full_ms) {
  if (full_ms == 0) { uart.disp("0 Hz"); return; }
  uint32_t hz_int   = 1000u / full_ms;                      // integer Hz
  uint32_t hz_milli = (1000000u / full_ms) - (hz_int*1000); // milli-Hz part
  uart.disp((int)hz_int); uart.disp(".");                   // X.
  // zero-pad to 3 digits
  if (hz_milli < 100) uart.disp("0");
  if (hz_milli < 10)  uart.disp("0");
  uart.disp((int)hz_milli); uart.disp(" Hz");
}

// Read RATEx (ticks) -> print ticks, half ms, full ms, approx Hz
static void print_rate_line(const char* name, uint32_t off) {
  uint32_t ticks = bl4_rd(off);
  uint32_t half_ms = ticks_to_ms(ticks);
  uint32_t full_ms = half_ms * 2u;

  uart.disp(name); uart.disp(": ");
  uart.disp((int)ticks); uart.disp(" ticks,  half=");
  uart.disp((int)half_ms); uart.disp(" ms,  full=");
  uart.disp((int)full_ms); uart.disp(" ms,  f≈");
  print_hz_from_full_ms(full_ms);
  nl();
}

// Pretty-print which channels toggled from a delta mask
static void print_delta_bits(uint8_t delta) {
  bool first = true;
  for (int ch=0; ch<4; ++ch) {
    if (delta & (1u<<ch)) {
      if (!first) uart.disp(",");
      uart.disp("CH"); uart.disp(ch);
      first = false;
    }
  }
  if (first) uart.disp("none");
}

// Watch STATUS and also name toggling channels
static void watch_status_named(int samples, int ms_between) {
  int last = (int)bl4_rd(BL4_STATUS);
  for (int i=0; i<samples; ++i) {
    sleep_ms(ms_between);
    int now = (int)bl4_rd(BL4_STATUS);
    int d = now ^ last;
    uart.disp("STATUS="); uart.disp(now); sp();
    uart.disp("delta="); uart.disp(d); sp(); uart.disp("(");
    print_delta_bits((uint8_t)d);
    uart.disp(")"); nl();
    last = now;
  }
}

// Dump all derived rates in ms/Hz
static void dump_rates_derived() {
  uart.disp("\r\n[Derived rates from tick registers]\r\n");
  print_rate_line("RATE0", BL4_RATE0);
  print_rate_line("RATE1", BL4_RATE1);
  print_rate_line("RATE2", BL4_RATE2);
  print_rate_line("RATE3", BL4_RATE3);
}


int main() {
  uart.disp("\r\n--- Blink4 Derived-Rate Report ---\r\n");

  // Example: visible half-periods (ms) -> software converts to ticks
  blink4_set_rates_ms(200, 400, 800, 1600);
  blink4_enable(0xF);

  // Show the raw registers (ticks) then the human view
  uart.disp("[Raw regs] "); 
  uart.disp("R0="); uart.disp((int)bl4_rd(BL4_RATE0)); sp();
  uart.disp("R1="); uart.disp((int)bl4_rd(BL4_RATE1)); sp();
  uart.disp("R2="); uart.disp((int)bl4_rd(BL4_RATE2)); sp();
  uart.disp("R3="); uart.disp((int)bl4_rd(BL4_RATE3)); nl();

  dump_rates_derived();

  uart.disp("\r\n[STATUS watch]\r\n");
  watch_status_named(20, 250); // 20 samples, 250 ms apart

  while (1) { sleep_ms(1000); }
  return 0;
}
