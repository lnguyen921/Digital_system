// blink4_core.h
#ifndef BLINK4_CORE_H_
#define BLINK4_CORE_H_

#include "chu_io_map.h"
#include "chu_io_rw.h"
#include <stdint.h>

#ifndef S4_BLINKER
#define S4_BLINKER 4
#endif

#define BL4_BASE get_slot_addr(BRIDGE_BASE, S4_BLINKER)

// word offsets inside the slot
enum : uint32_t {
  BL4_EN     = 0,
  BL4_RATE0  = 1,
  BL4_RATE1  = 2,
  BL4_RATE2  = 3,
  BL4_RATE3  = 4,
  BL4_STATUS = 5
};

#ifndef SYS_CLK_FREQ
#define SYS_CLK_FREQ 100  // MHz
#endif
#define CLK_HZ ((uint32_t)SYS_CLK_FREQ * 1000000u)

// Convert milliseconds to half-period ticks at CLK_HZ
static inline uint32_t ms_to_ticks(uint32_t ms) {
  return (uint64_t)ms * (CLK_HZ/1000u) / 2u;
}

// Low-level slot access (word offsets)
static inline void bl4_wr(uint32_t off, uint32_t v) { io_write(BL4_BASE, off, v); }
static inline uint32_t bl4_rd(uint32_t off)        { return io_read(BL4_BASE, off); }

// High-level helpers
static inline void blink4_set_rates_ms(uint32_t m0,uint32_t m1,uint32_t m2,uint32_t m3){
  bl4_wr(BL4_RATE0, ms_to_ticks(m0));
  bl4_wr(BL4_RATE1, ms_to_ticks(m1));
  bl4_wr(BL4_RATE2, ms_to_ticks(m2));
  bl4_wr(BL4_RATE3, ms_to_ticks(m3));
}
static inline void blink4_enable(uint8_t mask) { bl4_wr(BL4_EN, mask & 0x0F); }
static inline uint8_t blink4_status()          { return (uint8_t)(bl4_rd(BL4_STATUS) & 0x0F); }

#endif
