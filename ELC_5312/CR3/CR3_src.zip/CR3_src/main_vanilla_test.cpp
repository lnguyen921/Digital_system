/*****************************************************************//**
 * @file main_vanilla_test.cpp
 *
 * Basic test of 4 basic i/o cores
 *
 * Course: SoC 5312
 * Student: Loc Nguyen
 *********************************************************************/
/*****************************************************************//**
 * 
 *
 *  Test program for vanilla SoC + 4-LED blinker (slot 4)
 *
 * Combines  GPO/SW tests with hardware-timed blinking LEDs.
 *********************************************************************/

#include "chu_init.h"
#include "gpio_cores.h"
#include "blink4_core.h"

// -----------------------------------------------------------------------------
// Helper functions (upper 12 LEDs only; low 4 driven by blinker)
// -----------------------------------------------------------------------------
static inline void led_write_upper12(GpoCore* p, uint16_t val) {
  p->write((val & 0x0FFF) << 4);
}
static inline void led_set_bit(GpoCore* p, int idx) { p->write(1, idx); }
static inline void led_clr_bit(GpoCore* p, int idx) { p->write(0, idx); }

// -----------------------------------------------------------------------------
// reused from Chu examples (slightly masked)
// -----------------------------------------------------------------------------
void timer_check(GpoCore *led_p) {
  for (int i = 0; i < 5; i++) {
    led_write_upper12(led_p, 0x0FFF);
    sleep_ms(500);
    led_write_upper12(led_p, 0x0000);
    sleep_ms(500);
    debug("timer check loop:", i, "  now_ms:", now_ms());
  }
}

void led_check(GpoCore *led_p) {
  for (int i = 0; i < 12; i++) {
    led_set_bit(led_p, 4 + i);
    sleep_ms(150);
    led_clr_bit(led_p, 4 + i);
    sleep_ms(150);
  }
}

void sw_check(GpoCore *led_p, GpiCore *sw_p) {
  uint16_t s = sw_p->read() & 0x0FFF;
  for (int i = 0; i < 30; i++) {
    led_write_upper12(led_p, s);
    sleep_ms(50);
    led_write_upper12(led_p, 0);
    sleep_ms(50);
  }
}

void uart_check() {
  static int loop = 0;
  uart.disp("uart test #"); uart.disp(loop); uart.disp("\n\r");
  loop++;
}

// -----------------------------------------------------------------------------
// Main
// -----------------------------------------------------------------------------
GpoCore led(get_slot_addr(BRIDGE_BASE, S2_LED));
GpiCore sw(get_slot_addr(BRIDGE_BASE, S3_SW));

int main() {
  // ---- Configure 4-LED blinker (slot 4) ----
  blink4_set_rates_ms(200, 400, 800, 1600);
  blink4_enable(0xF);
  debug("Blink4 enabled. Status:", (int)blink4_status());

  // ---- Run legacy LED/SW/UART checks ----
  while (1) {
    timer_check(&led);
    led_check(&led);
    sw_check(&led, &sw);
    uart_check();
    debug("main loop: sw=", sw.read(), "  uptime_ms=", now_ms());
  }
}