/*****************************************************************//**
 * @file blink4_core.h
 *
 * @brief Simple driver for 4-LED blinker MMIO core (slot 4)
 *
 * @version v1.0  October 2025
 *********************************************************************/

#ifndef BLINK4_CORE_H_
#define BLINK4_CORE_H_

#include "chu_io_map.h"
#include "chu_init.h"
#include <stdint.h>

// -----------------------------------------------------------------------------
// Header file is for Blink4 
// -----------------------------------------------------------------------------
#ifndef S4_BLINKER
#define S4_BLINKER 4   // must match chu_io_map.svh
#endif

#define BLINK4_BASE   get_slot_addr(BRIDGE_BASE, S4_BLINKER)

// -----------------------------------------------------------------------------
// Register map (byte offsets)
// -----------------------------------------------------------------------------
enum : uint32_t {
  BLINK4_EN     = 0x00,
  BLINK4_RATE0  = 0x04,
  BLINK4_RATE1  = 0x08,
  BLINK4_RATE2  = 0x0C,
  BLINK4_RATE3  = 0x10,
  BLINK4_STATUS = 0x14
};

// -----------------------------------------------------------------------------
// Clock conversion helpers
// SYS_CLK_FREQ from chu_io_map.svh is in MHz
// -----------------------------------------------------------------------------
#ifndef SYS_CLK_FREQ
#define SYS_CLK_FREQ 100
#endif
#define CLK_HZ ((uint32_t)SYS_CLK_FREQ * 1000000u)

// -----------------------------------------------------------------------------
// Low-level MMIO helpers
// -----------------------------------------------------------------------------
static inline void wr32(uint32_t addr, uint32_t v) {
  *(volatile uint32_t*)addr = v;
}
static inline uint32_t rd32(uint32_t addr) {
  return *(volatile uint32_t*)addr;
}

// convert milliseconds to half-period clock counts
static inline uint32_t ms_to_ticks(uint32_t ms) {
  return (uint64_t)ms * (CLK_HZ/1000u) / 2u;
}

// -----------------------------------------------------------------------------
// API
// -----------------------------------------------------------------------------
static inline void blink4_set_rates_ms(uint32_t m0,uint32_t m1,
                                       uint32_t m2,uint32_t m3) {
  wr32(BLINK4_BASE + BLINK4_RATE0, ms_to_ticks(m0));
  wr32(BLINK4_BASE + BLINK4_RATE1, ms_to_ticks(m1));
  wr32(BLINK4_BASE + BLINK4_RATE2, ms_to_ticks(m2));
  wr32(BLINK4_BASE + BLINK4_RATE3, ms_to_ticks(m3));
}

static inline void blink4_enable(uint8_t mask) {
  wr32(BLINK4_BASE + BLINK4_EN, mask & 0x0F);
}

static inline uint8_t blink4_status() {
  return (uint8_t)(rd32(BLINK4_BASE + BLINK4_STATUS) & 0x0F);
}

#endif // BLINK4_CORE_H_
